Host: linux. VMM: firecracker. Iterations: fxfs-guest-dax 3.

| Workload | Unit | fxfs-guest-dax |
|---|---|---|
| sqlite-delete-full-batch100 | txn/s | 53.2 (53.1–54.1) |

- fxfs-guest-dax: mtime-ahead-of-guest-ms -5.87 median (-6.02–-2.42)
- fxfs-guest-dax: sqlite-delete-full-batch100-updates-per-second 5,317 median (5,311–5,411)

