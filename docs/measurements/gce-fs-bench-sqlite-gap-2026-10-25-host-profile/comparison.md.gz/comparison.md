Host: linux. VMM: firecracker. Iterations: fxfs-guest-dax 3.

| Workload | Unit | fxfs-guest-dax |
|---|---|---|
| sqlite-delete-full-batch100 | txn/s | 54.7 (54.5–54.7) |

- fxfs-guest-dax: mtime-ahead-of-guest-ms -4.64 median (-5.60–-2.94)
- fxfs-guest-dax: sqlite-delete-full-batch100-updates-per-second 5,469 median (5,445–5,474)

