Host: linux. VMM: firecracker. Iterations: fxfs-guest-dax 1.

| Workload | Unit | fxfs-guest-dax |
|---|---|---|
| sqlite-pread-scan | MiB/s | 657 (657–657) |
| sqlite-pread-scan-warm | MiB/s | 2,182 (2,182–2,182) |
| sqlite-mmap-scan | MiB/s | 2,820 (2,820–2,820) |
| sqlite-mmap-scan-warm | MiB/s | 3,183 (3,183–3,183) |
| sqlite-delete-full-batch1 | txn/s | 203 (203–203) |
| sqlite-delete-full-batch100 | txn/s | 35.8 (35.8–35.8) |
| sqlite-wal-full-batch1 | txn/s | 468 (468–468) |
| sqlite-wal-full-batch1-checkpoint | ms | 33.7 (33.7–33.7) |
| sqlite-wal-full-batch100 | txn/s | 118 (118–118) |
| sqlite-wal-full-batch100-checkpoint | ms | 80.9 (80.9–80.9) |
| sqlite-wal-normal-batch1 | txn/s | 16,875 (16,875–16,875) |
| sqlite-wal-normal-batch1-checkpoint | ms | 90.0 (90.0–90.0) |
| sqlite-wal-normal-batch100 | txn/s | 267 (267–267) |
| sqlite-wal-normal-batch100-checkpoint | ms | 113 (113–113) |

- fxfs-guest-dax: mtime-ahead-of-guest-ms -6.12 median (-6.12–-6.12)
- fxfs-guest-dax: sqlite-delete-full-batch1-updates-per-second 203 median (203–203)
- fxfs-guest-dax: sqlite-delete-full-batch100-updates-per-second 3,576 median (3,576–3,576)
- fxfs-guest-dax: sqlite-mmap-scan-faults-per-mib 17.0 median (17.0–17.0)
- fxfs-guest-dax: sqlite-mmap-scan-warm-faults-per-mib 16.9 median (16.9–16.9)
- fxfs-guest-dax: sqlite-pread-scan-faults-per-mib 16.0 median (16.0–16.0)
- fxfs-guest-dax: sqlite-pread-scan-warm-faults-per-mib 15.9 median (15.9–15.9)
- fxfs-guest-dax: sqlite-wal-full-batch1-updates-per-second 468 median (468–468)
- fxfs-guest-dax: sqlite-wal-full-batch100-updates-per-second 11,836 median (11,836–11,836)
- fxfs-guest-dax: sqlite-wal-normal-batch1-updates-per-second 16,875 median (16,875–16,875)
- fxfs-guest-dax: sqlite-wal-normal-batch100-updates-per-second 26,711 median (26,711–26,711)

Object storage: the extent daemon's requests to its bucket, for the cases that kept their
stores there, at GCS Standard single-region prices (class A $0.005 per 1,000, class B
$0.0004 per 1,000, deletes free).

| Request | Count | Class | Cost |
|---|---|---|---|
| get | 405 | B | $0.000162 |
| get-range | 2 | B | $0.000001 |
| head | 0 | B | $0.000000 |
| list | 13 | A | $0.000065 |
| create | 491 | A | $0.002455 |
| update | 2 | A | $0.000010 |
| overwrite | 0 | A | $0.000000 |
| delete | 1 | free | $0.000000 |
| all | 914 | | $0.002693 |

Uploaded 700.6 MiB (segments 540.6 MiB, extents 159.9 MiB, checkpoints 68.3 KiB, moves 0 B, other 66 B); downloaded 9.3 KiB.

Extent daemon: the VM processes' requests, as it served them, from their dispatch to their
reply.

| Request | Count | Each |
|---|---|---|
| open | 2 | 10,107.4 µs |
| read | 18,141 | 39.2 µs |
| write | 42,926 | 298.9 µs |
| free | 8,030 | 52.0 µs |
| map | 191,176 | 117.3 µs |
| unmap | 38,905 | 23.9 µs |
| commit | 60 | 1,156.2 µs |
| root | 9 | 0.8 µs |
| info | 12 | 1.5 µs |
| window | 2 | 17.1 µs |
| fault | 202 | 63.5 µs |
| transfer | 2 | 13.0 µs |
| free_many | 6,046 | 161.3 µs |

Commits: 23,943, 411.5 µs each: writing the open extents' 141.2 KiB 115.9 µs, committing the store 24.9 µs, sealing the windows' mappings 80.7 µs, waiting for object storage 189.6 µs.

Segments closed and framed: 394, 6.5 ms each.

