Host: linux. VMM: firecracker. Iterations: fxfs-guest-dax 10.

| Workload | Unit | fxfs-guest-dax |
|---|---|---|
| sqlite-wal-full-batch1 | txn/s | 530 (507–549) |
| sqlite-wal-full-batch1-checkpoint | ms | 36.4 (26.8–72.4) |

- fxfs-guest-dax: mtime-ahead-of-guest-ms -4.19 median (-6.87–-2.85)
- fxfs-guest-dax: sqlite-wal-full-batch1-updates-per-second 530 median (506–549)

Object storage: the extent daemon's requests to its bucket, for the cases that kept their
stores there, at GCS Standard single-region prices (class A $0.005 per 1,000, class B
$0.0004 per 1,000, deletes free).

| Request | Count | Class | Cost |
|---|---|---|---|
| get | 64 | B | $0.000026 |
| get-range | 1 | B | $0.000000 |
| head | 0 | B | $0.000000 |
| list | 3 | A | $0.000015 |
| create | 64 | A | $0.000320 |
| update | 2 | A | $0.000010 |
| overwrite | 0 | A | $0.000000 |
| delete | 1 | free | $0.000000 |
| all | 135 | | $0.000371 |

Uploaded 604.6 MiB (segments 604.6 MiB, extents 0 B, checkpoints 0 B, moves 0 B, other 39 B); downloaded 1.4 KiB.

Extent daemon: the VM processes' requests, as it served them, from their dispatch to their
reply.

| Request | Count | Each |
|---|---|---|
| open | 1 | 8,455.1 µs |
| read | 6,769 | 9.3 µs |
| write | 15,223 | 148.4 µs |
| free | 169 | 196.5 µs |
| map | 76,869 | 75.6 µs |
| unmap | 12,942 | 23.8 µs |
| commit | 20 | 140.8 µs |
| root | 1 | 0.8 µs |
| info | 4 | 0.9 µs |
| window | 1 | 12.2 µs |
| transfer | 1 | 8.2 µs |
| free_many | 203 | 1,031.0 µs |

Commits: 7,659, 264.5 µs each: writing the open extents' 92.9 KiB 79.9 µs, committing the store 13.4 µs, sealing the windows' mappings 61.7 µs, waiting for object storage 109.3 µs.

Segments closed and framed: 59, 20.9 ms each.

