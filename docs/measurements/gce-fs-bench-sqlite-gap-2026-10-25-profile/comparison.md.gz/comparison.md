Host: linux. VMM: firecracker. Iterations: fxfs-guest-dax 3.

| Workload | Unit | fxfs-guest-dax |
|---|---|---|
| sqlite-wal-normal-batch100 | txn/s | 184 (165–200) |
| sqlite-wal-normal-batch100-checkpoint | ms | 285 (111–331) |

- fxfs-guest-dax: mtime-ahead-of-guest-ms -3.44 median (-5.05–-2.49)
- fxfs-guest-dax: sqlite-wal-normal-batch100-updates-per-second 18,448 median (16,462–20,011)

Object storage: the extent daemon's requests to its bucket, for the cases that kept their
stores there, at GCS Standard single-region prices (class A $0.005 per 1,000, class B
$0.0004 per 1,000, deletes free).

| Request | Count | Class | Cost |
|---|---|---|---|
| get | 28 | B | $0.000011 |
| get-range | 1 | B | $0.000000 |
| head | 0 | B | $0.000000 |
| list | 3 | A | $0.000015 |
| create | 28 | A | $0.000140 |
| update | 2 | A | $0.000010 |
| overwrite | 0 | A | $0.000000 |
| delete | 1 | free | $0.000000 |
| all | 63 | | $0.000177 |

Uploaded 398.8 MiB (segments 398.8 MiB, extents 0 B, checkpoints 0 B, moves 0 B, other 39 B); downloaded 582 B.

Extent daemon: the VM processes' requests, as it served them, from their dispatch to their
reply.

| Request | Count | Each |
|---|---|---|
| open | 1 | 8,304.0 µs |
| read | 1,491 | 21.4 µs |
| write | 7,992 | 103.1 µs |
| free | 55 | 127.1 µs |
| map | 20,502 | 72.2 µs |
| unmap | 4,802 | 21.9 µs |
| commit | 16 | 4,491.5 µs |
| root | 1 | 1.3 µs |
| info | 4 | 0.9 µs |
| window | 1 | 21.2 µs |
| fault | 9 | 114.0 µs |
| transfer | 1 | 8.9 µs |
| free_many | 79 | 1,030.6 µs |

Commits: 1,706, 341.8 µs each: writing the open extents' 255.2 KiB 177.8 µs, committing the store 25.7 µs, sealing the windows' mappings 83.6 µs, waiting for object storage 54.5 µs.

Segments closed and framed: 23, 34.6 ms each.

