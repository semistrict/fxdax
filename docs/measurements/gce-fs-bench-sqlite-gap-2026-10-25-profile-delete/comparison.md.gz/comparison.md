Host: linux. VMM: firecracker. Iterations: fxfs-guest-dax 3.

| Workload | Unit | fxfs-guest-dax |
|---|---|---|
| sqlite-delete-full-batch100 | txn/s | 46.2 (45.6–46.9) |

- fxfs-guest-dax: mtime-ahead-of-guest-ms -4.40 median (-6.10–-3.78)
- fxfs-guest-dax: sqlite-delete-full-batch100-updates-per-second 4,623 median (4,560–4,692)

Object storage: the extent daemon's requests to its bucket, for the cases that kept their
stores there, at GCS Standard single-region prices (class A $0.005 per 1,000, class B
$0.0004 per 1,000, deletes free).

| Request | Count | Class | Cost |
|---|---|---|---|
| get | 42 | B | $0.000017 |
| get-range | 1 | B | $0.000000 |
| head | 0 | B | $0.000000 |
| list | 3 | A | $0.000015 |
| create | 42 | A | $0.000210 |
| update | 2 | A | $0.000010 |
| overwrite | 0 | A | $0.000000 |
| delete | 1 | free | $0.000000 |
| all | 91 | | $0.000252 |

Uploaded 599.1 MiB (segments 599.1 MiB, extents 0 B, checkpoints 0 B, moves 0 B, other 39 B); downloaded 918 B.

Extent daemon: the VM processes' requests, as it served them, from their dispatch to their
reply.

| Request | Count | Each |
|---|---|---|
| open | 1 | 8,648.0 µs |
| read | 2,053 | 11.3 µs |
| write | 7,039 | 279.9 µs |
| free | 543 | 194.7 µs |
| map | 86,447 | 142.9 µs |
| unmap | 8,550 | 29.5 µs |
| commit | 12 | 119.6 µs |
| root | 1 | 0.8 µs |
| info | 4 | 0.9 µs |
| window | 1 | 13.4 µs |
| transfer | 1 | 8.3 µs |
| free_many | 668 | 214.5 µs |

Commits: 3,494, 369.9 µs each: writing the open extents' 194.1 KiB 166.2 µs, committing the store 19.9 µs, sealing the windows' mappings 107.6 µs, waiting for object storage 75.9 µs.

Segments closed and framed: 37, 34.4 ms each.

