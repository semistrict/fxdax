Host: linux. VMM: firecracker. Iterations: fxfs-guest-dax 3.

| Workload | Unit | fxfs-guest-dax |
|---|---|---|
| sqlite-pread-scan | MiB/s | 836 (757–842) |
| sqlite-pread-scan-warm | MiB/s | 2,666 (2,579–2,696) |
| sqlite-mmap-scan | MiB/s | 3,518 (3,406–3,547) |
| sqlite-mmap-scan-warm | MiB/s | 3,823 (3,757–3,828) |
| sqlite-delete-full-batch1 | txn/s | 264 (263–268) |
| sqlite-delete-full-batch100 | txn/s | 55.2 (55.0–55.3) |
| sqlite-wal-full-batch1 | txn/s | 611 (599–629) |
| sqlite-wal-full-batch1-checkpoint | ms | 18.9 (15.7–23.2) |
| sqlite-wal-full-batch100 | txn/s | 153 (152–158) |
| sqlite-wal-full-batch100-checkpoint | ms | 70.2 (62.6–80.6) |
| sqlite-wal-normal-batch1 | txn/s | 22,854 (20,382–23,468) |
| sqlite-wal-normal-batch1-checkpoint | ms | 16.0 (15.4–38.1) |
| sqlite-wal-normal-batch100 | txn/s | 437 (336–446) |
| sqlite-wal-normal-batch100-checkpoint | ms | 186 (103–210) |

- fxfs-guest-dax: mtime-ahead-of-guest-ms -3.92 median (-6.05–-3.14)
- fxfs-guest-dax: sqlite-delete-full-batch1-updates-per-second 264 median (263–268)
- fxfs-guest-dax: sqlite-delete-full-batch100-updates-per-second 5,522 median (5,501–5,534)
- fxfs-guest-dax: sqlite-mmap-scan-faults-per-mib 3.70 median (3.70–3.70)
- fxfs-guest-dax: sqlite-mmap-scan-warm-faults-per-mib 3.60 median (3.60–3.70)
- fxfs-guest-dax: sqlite-pread-scan-faults-per-mib 2.70 median (2.60–2.70)
- fxfs-guest-dax: sqlite-pread-scan-warm-faults-per-mib 2.60 median (2.60–2.60)
- fxfs-guest-dax: sqlite-wal-full-batch1-updates-per-second 611 median (598–629)
- fxfs-guest-dax: sqlite-wal-full-batch100-updates-per-second 15,276 median (15,180–15,753)
- fxfs-guest-dax: sqlite-wal-normal-batch1-updates-per-second 22,854 median (20,382–23,468)
- fxfs-guest-dax: sqlite-wal-normal-batch100-updates-per-second 43,673 median (33,585–44,617)

Object storage: the extent daemon's requests to its bucket, for the cases that kept their
stores there, at GCS Standard single-region prices (class A $0.005 per 1,000, class B
$0.0004 per 1,000, deletes free).

| Request | Count | Class | Cost |
|---|---|---|---|
| get | 70 | B | $0.000028 |
| get-range | 1 | B | $0.000000 |
| head | 0 | B | $0.000000 |
| list | 4 | A | $0.000020 |
| create | 314 | A | $0.001570 |
| update | 2 | A | $0.000010 |
| overwrite | 0 | A | $0.000000 |
| delete | 1 | free | $0.000000 |
| all | 392 | | $0.001628 |

Uploaded 2.0 GiB (segments 1.5 GiB, extents 479.8 MiB, checkpoints 5.0 KiB, moves 0 B, other 39 B); downloaded 1.6 KiB.

Extent daemon: the VM processes' requests, as it served them, from their dispatch to their
reply.

| Request | Count | Each |
|---|---|---|
| open | 1 | 9,334.3 µs |
| read | 3,976 | 33.2 µs |
| write | 13,439 | 1,057.0 µs |
| free | 597 | 175.3 µs |
| map | 111,956 | 126.7 µs |
| unmap | 17,970 | 31.1 µs |
| commit | 22 | 2,100.3 µs |
| root | 1 | 1.0 µs |
| info | 4 | 0.9 µs |
| window | 1 | 11.6 µs |
| transfer | 1 | 9.3 µs |
| free_many | 1,349 | 274.7 µs |

Commits: 6,680, 1,886.5 µs each: writing the open extents' 319.8 KiB 229.5 µs, committing the store 150.9 µs, sealing the windows' mappings 106.1 µs, waiting for object storage 1,399.9 µs.

Segments closed and framed: 65, 49.3 ms each.

