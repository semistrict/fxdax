Host: linux. VMM: firecracker. Iterations: fxfs-guest-dax 3.

| Workload | Unit | fxfs-guest-dax |
|---|---|---|
| sqlite-pread-scan | MiB/s | 826 (806–841) |
| sqlite-pread-scan-warm | MiB/s | 2,669 (2,665–2,715) |
| sqlite-mmap-scan | MiB/s | 3,395 (3,354–3,467) |
| sqlite-mmap-scan-warm | MiB/s | 3,686 (3,654–3,737) |
| sqlite-delete-full-batch1 | txn/s | 261 (257–264) |
| sqlite-delete-full-batch100 | txn/s | 46.9 (46.5–47.4) |
| sqlite-wal-full-batch1 | txn/s | 596 (575–609) |
| sqlite-wal-full-batch1-checkpoint | ms | 20.1 (19.9–21.8) |
| sqlite-wal-full-batch100 | txn/s | 106 (105–106) |
| sqlite-wal-full-batch100-checkpoint | ms | 94.1 (90.9–103) |
| sqlite-wal-normal-batch1 | txn/s | 12,418 (7,769–13,092) |
| sqlite-wal-normal-batch1-checkpoint | ms | 29.3 (18.5–37.3) |
| sqlite-wal-normal-batch100 | txn/s | 198 (189–226) |
| sqlite-wal-normal-batch100-checkpoint | ms | 201 (151–338) |

- fxfs-guest-dax: mtime-ahead-of-guest-ms -5.21 median (-6.43–-4.70)
- fxfs-guest-dax: sqlite-delete-full-batch1-updates-per-second 260 median (257–264)
- fxfs-guest-dax: sqlite-delete-full-batch100-updates-per-second 4,693 median (4,654–4,742)
- fxfs-guest-dax: sqlite-mmap-scan-faults-per-mib 7.70 median (5.60–9.60)
- fxfs-guest-dax: sqlite-mmap-scan-warm-faults-per-mib 7.60 median (5.60–9.60)
- fxfs-guest-dax: sqlite-pread-scan-faults-per-mib 2.70 median (2.60–2.70)
- fxfs-guest-dax: sqlite-pread-scan-warm-faults-per-mib 2.60 median (2.60–2.60)
- fxfs-guest-dax: sqlite-wal-full-batch1-updates-per-second 596 median (575–609)
- fxfs-guest-dax: sqlite-wal-full-batch100-updates-per-second 10,594 median (10,520–10,608)
- fxfs-guest-dax: sqlite-wal-normal-batch1-updates-per-second 12,418 median (7,769–13,092)
- fxfs-guest-dax: sqlite-wal-normal-batch100-updates-per-second 19,754 median (18,855–22,568)

